import java.util.Random;
/**
 * Created by Nico on 8/30/15.
 */
public class Player {
    private Deck deck;
    private String name;

    public Player(Deck deck,int i) {
        this.deck = deck;
        name=Integer.toString(i);;
    }

   // public Player(){}

    public Card play() {
        if (deck.getQuantityCards() > 0) {
            return this.deck.getCard();
        }
        else
            return null;
    }

    public Player(String name) {
    	this.name=name;
    }

    public String getName(){
    	return name;
    }
    public void addCard(Card card) {
        this.deck.addCard(card);
    }

    public Card getCard() {
        Card lostCard = this.deck.getCard();
        this.deck.removeCard();
        return lostCard;
    }

    public int remainingCards() {
        return deck.getQuantityCards();
    }

    public int selectAttribute() {
        Random randomGenerator = new Random();
        return randomGenerator.nextInt(deck.getAttributesAmount() - 1);
    }
}
