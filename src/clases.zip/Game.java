import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Nico on 8/30/15.
 */
public class Game {
	Deck deck;
	int playersAmount;
	int runWinner = 0;
	ArrayList<Deck> decksPlayers = new ArrayList<Deck>();
	ArrayList<Player> players = new ArrayList<Player>();
	HashMap<Card, Player> cardsOwners = new HashMap<Card, Player>();

	public Game(Deck deck, int playersAmount) {
		this.deck = deck;
		this.playersAmount = playersAmount;
		this.runWinner = 0; 
		for (int i = 0; i < playersAmount; i++) {
			Deck newDeck = new Deck();
			decksPlayers.add(newDeck);
			Player newPlayer = new Player(decksPlayers.get(i),i);
			players.add(newPlayer);
		}
		dealCards();
	}

	public void play(){
		int i=0;
		while(!existWinner() && (!existTie())){
			System.out.println("i: "+ i);
			i++;
			nextRound();
		}
		if(existWinner()){
			System.out.println("i: "+ i);
			System.out.println("Gano el jugador: " + players.get(0).getName());
		}
	}

	private void nextRound() {
		removeLosers();
		if (!existWinner() && (!existTie())){
		Card card;
		ArrayList<Card> cardsInPlay = new ArrayList<>();
		int attributeInGame = players.get(runWinner).selectAttribute();
		for (Player player : players) {
			card = player.getCard();
			cardsOwners.put(card,player);
			cardsInPlay.add(card);
		}
		System.out.println("tama�o de car in play"+ cardsInPlay.size());
		int winCard = winCard(cardsInPlay, attributeInGame);
		selectWin(winCard,attributeInGame,cardsInPlay,null);

	}
	}


	private void selectWin(int winCard, int attributeInGame, ArrayList<Card> cardsInPlay, ArrayList<Card> reward) {
		
		if (winCard == -1){
			tiebreaker(attributeInGame,cardsInPlay);
			System.out.println("J53");
		}
		else 
		{
			System.out.println("Player playerWin = cardsOwners.get(cardsInPlay.get(winCard));" + cardsOwners.get(cardsInPlay.get(winCard)));
			Player playerWin = cardsOwners.get(cardsInPlay.get(winCard));
			this.runWinner = players.indexOf(playerWin);
			deliveryCards(cardsInPlay,null);
		}
	}

	private void deliveryCards( ArrayList<Card> cardsInPlay, ArrayList<Card> reward) {
		Deck newDeck = decksPlayers.get(runWinner);
		for (Card card : cardsInPlay) {
			newDeck.addCard(card);			
		}
		System.out.println("card antes reward");
		if (reward!= null){
		for (Card card : reward) {
			System.out.println("car reward");
			newDeck.addCard(card);
			}			
		}
		decksPlayers.set(runWinner, newDeck);

	}

	private void tiebreaker(int attributeInGame, ArrayList<Card> cardsInPlay) {
		if(!existWinner() && (!existTie())){ 
			ArrayList<Card> cardsInTie = cardsInPlay;
			cardsInPlay.clear();
			Card card;
			for (Player player : players) {
				card = player.getCard();
				cardsOwners.put(card,player);
				cardsInPlay.add(card);
			}
			int winCard = winCard(cardsInPlay, attributeInGame);
			selectWin(winCard, attributeInGame, cardsInTie, cardsInPlay);
		}

	}

	private boolean existTie() {
		if (players.size() == 0)
		{System.out.println("entro al empate");
			return true;}
		else
			return false;
	}

	private void dealCards() {
		while (deck.getQuantityCards() >= players.size()) {
			for (int i = 0; i <= players.size() - 1 ; i++) {
				players.get(i).addCard(deck.getCard());
			}
		}
	}

	private boolean existWinner() {
		if (players.size() == 1)
		{	System.out.println("alguien Gano");
			return true;
		}
		else
			return false;
	}


	private int winCard(ArrayList<Card> cardInPlay, int attributeSelector) {
		
		int pos = 0;
		Boolean tie=false;
		System.out.println(cardInPlay.size());
		System.out.println("cardInPlay.size()" + cardInPlay.get(pos).getAttribute(attributeSelector));
		System.out.println("cardInPlay.size()" + cardInPlay.get(1).getAttribute(attributeSelector));
		
		for (int i = 1; i < cardInPlay.size()-1; i++) {
			if(cardInPlay.get(pos).getAttribute(attributeSelector) < cardInPlay.get(i).getAttribute(attributeSelector)){
				pos = i;
				System.out.println("J3");
				if (tie){
					tie = false;
				}
			}
			else
			{
				if(cardInPlay.get(pos).getAttribute(attributeSelector) == cardInPlay.get(i).getAttribute(attributeSelector)){
					tie = true;
					System.out.println("Empate");					
				}
			}
		}
		if (!tie){
			return pos;
		}
		else{
			return -1;
		}
	}


	private void removeLosers() {
		
		for (int i = 0; i < this.players.size(); i++) {
			if (this.players.get(i).remainingCards() == 0) {
				System.out.println("removio al jugador: "+ players.get(i).getName());
				this.players.remove(this.players.get(i));
			}
		}
	}
	/* 
	private Card loserCard(Card cardOpponent1, Card cardOpponent2, int attribute) {
		int condition = cardOpponent1.getAttributeCondition(attribute);
		int attributteCard1 = cardOpponent1.getAttribute(attribute) * condition;
		int attributteCard2 = cardOpponent2.getAttribute(attribute) * condition;
		if (attributteCard1 > attributteCard2) {
			return cardOpponent2;
		} else if (attributteCard2 > attributteCard1) {
			return cardOpponent1;
		} else {
			return null;
		}
	}*/
}
